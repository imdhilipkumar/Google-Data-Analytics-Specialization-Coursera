# We will use the `describe()` method in Pandas to generate these statistics for the `df_activity` dataset. This method provides a comprehensive summary of 
# the numerical columns in the dataset, including count, mean, standard deviation, minimum, percentiles, and maximum values. Let's calculate these statistics.
    
# pull general statistics
df_activity.describe()